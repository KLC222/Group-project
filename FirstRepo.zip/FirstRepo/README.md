# simple-website-html-css-js
This is a simple website. 
Please ensure that you read this file before proceeding. 

It uses html, css and javascript.   
Website Link: https://deirdreodonovan.github.io/simple-website/
This is the second change that I have made to this file 
